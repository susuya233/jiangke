#!/bin/sh

fname=`date +"%Y-%m-%d-%T" | sed 's/-//g' | sed 's/://g'`

echo "Pragma: no-cache"
echo "Cache-control: no-cache"
echo "Content-type: application/octet-stream"
echo "Content-Transfer-Encoding: binary"
echo "Content-Disposition: attachment; filename="$fname.log""
echo ""

# Export parts
cat /var/log/traffic_ctrl/log.txt 2>/dev/null
