#!/bin/sh
model=`nvram_get 2860 Model`
login=`cat /var/tmp/web_login_status`

if [ "$login" -lt "2" ]; then
exit 0
fi


echo "Pragma: no-cache"
echo "Cache-control: no-cache"
echo "Content-type: application/octet-stream"
echo "Content-Transfer-Encoding: binary"
echo "Content-Disposition: attachment; filename="$model-settings.dat""
echo ""

# Export parts
echo "#tlr1055 settings export file"
for entry in `ls /var/store/xmlp/*.xml`; do
echo ""
echo "filename:"$entry
cat $entry 2>/dev/null
done
