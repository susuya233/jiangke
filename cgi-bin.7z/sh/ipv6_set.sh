#!/bin/sh
. /sbin/config.sh
. /sbin/global.sh

if [ "$CONFIG_IPV6" != "" ]; then


start()
{

#opmode=`nvram_get 2860 IPV6_OPMODE`
opmode=`xmlp_get 'internet\ipv6' ipv6_opmode`

ip link set 6rdtun down
echo "0" > /proc/sys/net/ipv6/conf/all/forwarding

if [ "$opmode" = "1" ]; then

ipv6_lan_ipaddr=`xmlp_get 'internet\ipv6\static\ipv6_lan_ipaddr' ipv6_lan_ipaddr`
ipv6_lan_prefix_len=`xmlp_get 'internet\ipv6\static\ipv6_lan_prefix_len' ipv6_lan_prefix_len`
ipv6_wan_ipaddr=`xmlp_get 'internet\ipv6\static\ipv6_wan_ipaddr' ipv6_wan_ipaddr`
ipv6_wan_prefix_len=`xmlp_get 'internet\ipv6\static\ipv6_wan_prefix_len' ipv6_wan_prefix_len`
ipv6_static_gw=`xmlp_get 'internet\ipv6\static\ipv6_static_gw' ipv6_static_gw`
WANIF=`ip -4 route|grep default|awk '{print $5}'`

ifconfig $lan_if add $ipv6_lan_ipaddr/$ipv6_lan_prefix_len
#echo ifconfig $lan_if add $ipv6_lan_ipaddr/$ipv6_lan_prefix_len
ifconfig $WANIF add $ipv6_wan_ipaddr/$ipv6_wan_prefix_len
#echo ifconfig $WANIF add $ipv6_wan_ipaddr/$ipv6_wan_prefix_len
route -A inet6 add default gw $ipv6_static_gw dev eth2.2
#echo route -A inet6 add default gw $ipv6_static_gw dev eth2.2
echo "1" > /proc/sys/net/ipv6/conf/all/forwarding

elif [ "$opmode" = "2" ]; then

ipv6_6rd_prefix=`xmlp_get 'internet\ipv6\ip6rd\ipv6_6rd_prefix' ipv6_6rd_prefix`
ipv6_6rd_prefix_len=`xmlp_get 'internet\ipv6\ip6rd\ipv6_6rd_prefix_len' ipv6_6rd_prefix_len`
ipv6_6rd_border_ipaddr=`xmlp_get 'internet\ipv6\ip6rd\ipv6_6rd_border_ipaddr' ipv6_6rd_border_ipaddr`
ipv6_6rd_ip_addr=`xmlp_get 'internet\ipv6\ip6rd\ipv6_6rd_ip_addr' ipv6_6rd_ip_addr`
WANIF=`ip -4 route|grep default|awk '{print $5}'`
WANIP=`ip -4 addr show dev $WANIF | awk '/inet / {print $2}' | cut -d/ -f 1`
#WANIPSPACED=`echo $WANIP | tr . ' '`
#echo $WANIF $WANIP

ip tunnel add 6rdtun mode sit local $ipv6_6rd_border_ipaddr ttl 64
#echo ip tunnel add 6rdtun mode sit local $WANIP ttl 64
ip tunnel 6rd dev 6rdtun 6rd-prefix $ipv6_6rd_prefix::/$ipv6_6rd_prefix_len
#echo ip tunnel 6rd dev 6rdtun 6rd-prefix $ipv6_6rd_prefix::/$ipv6_6rd_prefix_len
ip addr add $ipv6_6rd_ip_addr::1/$ipv6_6rd_prefix_len dev 6rdtun
#echo ip addr add $ipv6_6rd_ip_addr::1/$ipv6_6rd_prefix_len dev 6rdtun
ip link set 6rdtun up
#echo ip link set 6rdtun up
ip route add ::/0 via ::$ipv6_6rd_border_ipaddr dev 6rdtun
#echo ip route add ::/0 via ::$ipv6_6rd_border_ipaddr dev 6rdtun
ip addr add $ipv6_6rd_ip_addr::1/64 dev $lan_if
#echo ip addr add $ipv6_6rd_ip_addr::1/64 dev $lan_if
echo "1" > /proc/sys/net/ipv6/conf/all/forwarding
radvd.sh $ipv6_6rd_ip_addr
#echo radvd.sh $ipv6_6rd_ip_addr

elif [ "$opmode" = "3" ]; then

ipv6_ds_wan_ipaddr=`xmlp_get 'internet\ipv6\dslite\ipv6_ds_wan_ipaddr' ipv6_ds_wan_ipaddr`
ipv6_ds_aftr_ipaddr=`xmlp_get 'internet\ipv6\dslite\ipv6_ds_aftr_ipaddr' ipv6_ds_aftr_ipaddr`
ipv6_ds_gw_ipaddr=`xmlp_get 'internet\ipv6\dslite\ipv6_ds_gw_ipaddr' ipv6_ds_gw_ipaddr`

config-dslite.sh $ipv6_ds_aftr_ipaddr $ipv6_ds_wan_ipaddr $ipv6_ds_gw_ipaddr
#echo config-dslite.sh $ipv6_ds_aftr_ipaddr $ipv6_ds_wan_ipaddr $ipv6_ds_gw_ipaddr

fi

#echo "end"
}

stop()
{
opmode=`xmlp_get 'internet\ipv6' ipv6_opmode`
#echo $opmode
if [ "$opmode" = "1" ]; then

ipv6_lan_ipaddr=`xmlp_get 'internet\ipv6\static\ipv6_lan_ipaddr' ipv6_lan_ipaddr`
ipv6_lan_prefix_len=`xmlp_get 'internet\ipv6\static\ipv6_lan_prefix_len' ipv6_lan_prefix_len`
ipv6_wan_ipaddr=`xmlp_get 'internet\ipv6\static\ipv6_wan_ipaddr' ipv6_wan_ipaddr`
ipv6_wan_prefix_len=`xmlp_get 'internet\ipv6\static\ipv6_wan_prefix_len' ipv6_wan_prefix_len`
ipv6_static_gw=`xmlp_get 'internet\ipv6\static\ipv6_static_gw' ipv6_static_gw`
WANIF=`ip -4 route|grep default|awk '{print $5}'`

WANV6S=`ifconfig $lan_if|grep inet6|grep -v fe80|grep -i $ipv6_lan_ipaddr|awk '{print $3}'`
ip -6 addr del $WANV6S dev $lan_if

USBV6S=`ifconfig $WANIF|grep inet6|grep -v fe80|grep -i $ipv6_wan_ipaddr|awk '{print $3}'`
ip -6 addr del $USBV6S dev $WANIF

elif [ "$opmode" = "2" ]; then

ipv6_6rd_prefix=`xmlp_get 'internet\ipv6\ip6rd\ipv6_6rd_prefix' ipv6_6rd_prefix`
#echo $ipv6_6rd_prefix

ip tunnel del 6rdtun
ip link set sit0 down

WANV6S=`ifconfig $lan_if|grep inet6|grep -v fe80|grep -i $ipv6_6rd_prefix|awk '{print $3}'`
#echo $WANV6S
while [ -n "$WANV6S" ]
do
ip -6 addr del $WANV6S dev $lan_if
#echo 6rd "Removing IP $WANV6S from device $lan_if..."
WANV6S=`ifconfig $lan_if|grep inet6|grep -v fe80|grep -i $ipv6_6rd_prefix|awk '{print $3}'`
done

elif [ "$opmode" = "3" ]; then
ipv6_ds_wan_ipaddr=`xmlp_get 'internet\ipv6\dslite\ipv6_ds_wan_ipaddr' ipv6_ds_wan_ipaddr`
#echo $ipv6_ds_wan_ipaddr

ip link set dsltun down
ip tunnel del dsltun

WANV6S=`ifconfig $wan_if|grep inet6|grep -v fe80|grep -i $ipv6_ds_wan_ipaddr|awk '{print $3}'`
#echo $WANV6S
while [ -n "$WANV6S" ]
do
ip -6 addr del $WANV6S dev $wan_if
#echo dslite "Removing IP $WANV6S from device $wan_if..."
WANV6S=`ifconfig $wan_if|grep inet6|grep -v fe80|grep -i $ipv6_ds_wan_ipaddr|awk '{print $3}'`
done
fi
}

if [ "$1" = "" ]; then
echo "$0: insufficient arguments"
elif [ "$1" = "start" ]; then
start
elif [ "$1" = "stop" ]; then
stop
else
echo "$0: unknown argument: $1"
fi

fi

