#!/bin/sh
#
# $Id: //WIFI_SOC/MP/SDK_4_2_0_0/RT288x_SDK/source/user/rt2880_app/scripts/ntp.sh#1 $
#
# usage: ntp.sh
#

srv=`nvram_get 2860 NTPServerIP`
sync=`nvram_get 2860 NTPSync`
tz=`nvram_get 2860 TZ`


killall -q ntpclient

if [ "$srv" = "" ]; then
exit 0
fi


#if [ "$sync" = "" ]; then
# sync=1
#elif [ $sync -lt 300 -o $sync -le 0 ]; then
# sync=1
#fi

sync=`expr $sync 3g.sh accel-pptp.sh admin_ddns.sh admin_factory_settings.sh admin_import_settings.sh admin_lan.sh admin_ntp.sh admin_update.sh affinity.sh arp autoReset-Refresh.sh autoconn3G.sh automount.sh automount_boot.sh check-dnsmasq.sh chpasswd.sh config-3g-ppp.sh config-dns.sh config-dns2.sh config-dslite.sh config-iTunes.sh config-igmpproxy.sh config-l2tp.sh config-powersave.sh config-pppoe.sh config-pptp.sh config-udhcpd.sh config-vlan.sh config.sh cpubusy.sh ddns.sh fdisk firewall_dmz.sh firewall_filtering.sh firewall_forwarding.sh firewall_init.sh firewall_udptr.sh firewall_vpn.sh getty global.sh gtd.sh gtp.sh halt hnat_dbg.sh hso_connect.sh ifconfig init insmod internet.sh internet_lan.sh internet_wan.sh ipv6_logo.sh ipv6_set.sh klogd lan.sh lan_link.sh logread lsmod lspci lte_init.sh lte_setting.sh make_default_ssid.sh management_init.sh mdev miniupnpd.sh mkdosfs nat.sh nmbd ntp.sh openl2tp.sh openl2tpd pcie_enumerate_reboot.sh poweroff pppoe.sh radvd read_sms reboot rmmod route rps.sh sd_rw_test.sh send_sms setpci sigmon smbd smbpasswd smp.sh snmp.sh snort.sh storage.sh syslogd tcpdump udhcpc udhcpc.sh update-dns.sh vconfig vpn-passthru.sh wan.sh wan_conn_check.sh wanlan_mode.sh wifi2g_advanced.sh wifi2g_basic.sh wifi2g_radioOnOff.sh wifi2g_security.sh wifi2g_wifiOnOff.sh wifi5g_advanced.sh wifi5g_basic.sh wifi5g_radioOnOff.sh wifi5g_security.sh wifi5g_wifiOnOff.sh wifi_unload.sh 3600`

if [ "$tz" = "" ]; then
tz="UCT_000"
fi

#debug
#echo "serv=$srv"
#echo "sync=$sync"
#echo "tz=$tz"

echo $tz > /etc/tmpTZ
sed -e 's#.*_(-*)0*(.*)#GMT-12#' /etc/tmpTZ > /etc/tmpTZ2
sed -e 's#(.*)--(.*)#12#' /etc/tmpTZ2 > /etc/TZ
rm -rf /etc/tmpTZ
rm -rf /etc/tmpTZ2
ntpclient -s -c 0 -h $srv -i $sync &

