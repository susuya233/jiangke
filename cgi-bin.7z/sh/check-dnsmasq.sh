#!/bin/sh

## Check "system\weblogin","first_login"
## if first_login == "1" && exist /etc/dnsmasq.conf ==> do not thing ( or dnsmasq start )
## if first_login == "1" && not exist /etc/dnsmasq.conf ==> create /etc/dnsmasq.conf and dnsmasq start(restart)
## if first_login == "0" && not exist /etc/dnsmasq.conf ==> do not thing ( or dnsmasq start )
## if first_login == "0" && exist /etc/dnsmasq.conf ==> delete /etc/dnsmasq.conf and dnsmasq start(restart)

#pd=`nvram_get 2860 wan_primary_dns`
#sd=`nvram_get 2860 wan_secondary_dns`

rm -f /etc/dnsmasq.conf
killall -9 dnsmasq

#config-udhcpd.sh -d $pd $sd
#config-udhcpd.sh -r 1

dnsmasq -u root -c 0 -h -H /tmp/iphost -n -N -d --resolv-file=/etc/resolv.conf &

