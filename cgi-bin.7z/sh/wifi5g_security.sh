#!/bin/sh

. /sbin/config.sh

#confWPAGeneral()
#{
# `xmlp_set wifi\\wifi_5g\\basic\\ssid\\security_$1\\wep default_key_id 2`
# `xmlp_set wifi\\wifi_5g\\basic\\ssid\\security_$1\\wep rekey_method TIME`
# `xmlp_set wifi\\wifi_5g\\basic\\ssid\\security_$1 ieee8021x 0`
#}

#count=`xmlp_get 'wifi\wifi_5g\basic\ssid' count`
#wsc_mode_option=`xmlp_get 'wifi\wifi_5g\basic\security' wsc_mode_option`

if [ "$1" -eq "1" ]; then
i="1"
elif [ "$1" -eq "2" ]; then
i="2"
elif [ "$1" -eq "3" ]; then
i="3"
elif [ "$1" -eq "4" ]; then
i="4"
elif [ "$1" -eq "5" ]; then
i="5"
elif [ "$1" -eq "6" ]; then
i="6"
elif [ "$1" -eq "7" ]; then
i="7"
elif [ "$1" -eq "8" ]; then
i="8"
else
echo "$0 : unknown SSID $1"
echo "MAX SSID is 8"
exit 1
fi

security_mode=`xmlp_get wifi\\wifi_5g\\basic\\ssid\\security_$i auth_mode`
if [ "$security_mode" = "OPNE" -o "$security_mode" = "SHARED" -o "$security_mode" = "WEPAUTO" ]; then
# `xmlp_set wifi\\wifi_5g\\basic\\ssid\\security_$i encrypt_type WEP`
# `xmlp_set 'wifi\wifi_5g\basic\security' wsc_mode_option 0`
if [ "$CONFIG_USER_MINIUPNPD" != "" ];then
miniupnpd.sh init
else
kill -9 `cat /var/run/wscd.pid.rai0`
fi
route delete 239.255.255.250 1>/dev/null 2>&1

#elif [ "$security_mode" = "WPA" ]; then
# confWPAGeneral $i
#elif [ "$security_mode" = "WPAPSK" ]; then
# confWPAGeneral $i
#elif [ "$security_mode" = "WPA2" -o "$security_mode" = "WPA1WPA2" ]; then
# confWPAGeneral $i
#elif [ "$security_mode" = "WPA2PSK" -o "$security_mode" = "WPAPSKWPA2PSK" ]; then
# confWPAGeneral $i
#elif [ "$security_mode" = "IEEE8021X" ]; then
# `xmlp_set wifi\\wifi_5g\\basic\\ssid\\security_$i ieee8021x 1`
# `xmlp_set wifi\\wifi_5g\\basic\\ssid\\security_$i auth_mode OPEN`
# ieee8021x_wep=`xmlp_get 'wifi\wifi_5g\basic\ssid\security_1' ieee8021x`
# if [ "$ieee8021x_wep" -eq "0" ]; then
# `xmlp_set wifi\\wifi_5g\\basic\\ssid\\security_$i encrypt_type NONE`
# elif [ "$ieee8021x_wep" -eq "1" ]; then
# `xmlp_set wifi\\wifi_5g\\basic\\ssid\\security_$i encrypt_type WEP`
# fi
#elif [ "$security_mode" = "WAICERT" ]; then
# `xmlp_set wifi\\wifi_5g\\basic\\ssid\\security_$i encrypt_type SMS4`
# `xmlp_set 'wifi\wifi_5g\basic\security' wapi_ifname br0`
# `xmlp_set wifi\\wifi_5g\\basic\\ssid\\security_$i\\wapi wapi_as_port 3810`
#elif [ "$security_mode" = "WAIPSK" ]; then
# `xmlp_set wifi\\wifi_5g\\basic\\ssid\\security_$i encrypt_type SMS4`
#else
# `xmlp_set wifi\\wifi_5g\\basic\\ssid\\security_$i auth_mode OPEN`
# `xmlp_set wifi\\wifi_5g\\basic\\ssid\\security_$i encrypt_type NONE`
fi

#if [ "$wsc_mode_option" != "0" ]; then
# `iwpriv ra0 set WscConfStatus=1`
#fi
#`xmlp_set 'wifi\wifi_5g\basic\security' wsc_configured 1`

nvramxmlp tonvram wifi5g_basic
internet.sh



